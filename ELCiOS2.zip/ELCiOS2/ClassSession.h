//
//  ClassSession.h
//  
//
//  Created by Eric Wang on 4/3/16.
//
//

#import <Foundation/Foundation.h>

@interface ClassSession : NSObject

@end
