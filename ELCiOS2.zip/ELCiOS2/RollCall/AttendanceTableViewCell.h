//
//  AttendanceTableViewCell.h
//  RollCall
//
//  Created by Eric Wang on 3/3/16.
//  Copyright © 2016 Eric Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AttendanceTableViewCell : UITableViewCell

@property (nonatomic,strong) UILabel *nameDateLabel;
@property (nonatomic,strong) UIImageView *attendanceTracker;

@end
