//
//  main.m
//  RollCall
//
//  Created by Eric Wang on 2/26/16.
//  Copyright © 2016 Eric Wang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
