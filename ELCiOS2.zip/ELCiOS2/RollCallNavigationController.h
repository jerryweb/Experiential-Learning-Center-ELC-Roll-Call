//
//  RollCallNavigationController.h
//  RollCall
//
//  Created by Eric Wang on 3/20/16.
//  Copyright © 2016 Eric Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RollCallNavigationController : UINavigationController

@end
