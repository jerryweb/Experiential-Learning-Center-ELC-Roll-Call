//
//  StudentAttendanceHistoryViewController.h
//  RollCall
//
//  Created by Eric Wang on 2/29/16.
//  Copyright © 2016 Eric Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StudentAttendanceHistoryViewController : UIViewController

@end
